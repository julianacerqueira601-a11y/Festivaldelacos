import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { formatMoney, pad4 } from "@/lib/format";
import { ORDER_STATUS_LABELS } from "@/lib/types";
import Link from "next/link";

export const revalidate = 0;

export default async function PedidoPage({ params }: { params: { id: string } }) {
  const supabase = supabaseAdmin();

  const { data: order } = await supabase
    .from("orders")
    .select("order_number, total, status, delivery_method, customers(whatsapp)")
    .eq("id", params.id)
    .single();

  const { data: settings } = await supabase
    .from("settings")
    .select("whatsapp_number, confirmation_message")
    .eq("id", 1)
    .single();

  if (!order) {
    return <main className="px-5 pt-10 text-center text-ink2 text-sm">Pedido não encontrado.</main>;
  }

  const orderNum = pad4(order.order_number);
  const waText = encodeURIComponent(`Olá! Fiz o pagamento do pedido #${orderNum} do Festival de Laços.`);
  const waNumber = (settings?.whatsapp_number ?? "").replace(/\D/g, "");

  return (
    <main className="px-5 pt-10 pb-10 text-center">
      <p className="text-4xl">🎀</p>
      <h1 className="font-display text-2xl mt-3">Pedido recebido!</h1>
      <p className="text-ink2 text-sm mt-1">Pedido #{orderNum}</p>

      <div className="card mt-6 p-4 text-left">
        <p className="text-sm">
          {settings?.confirmation_message ??
            "Seu pagamento será conferido. Assim que for confirmado, seu pedido será separado."}
        </p>
        <div className="flex justify-between text-xs text-ink2 mt-3 pt-3 border-t border-black/5">
          <span>Status</span>
          <span className="font-semibold text-ink">{ORDER_STATUS_LABELS[order.status as keyof typeof ORDER_STATUS_LABELS]}</span>
        </div>
        <div className="flex justify-between text-xs text-ink2 mt-1">
          <span>Total</span>
          <span className="font-semibold text-ink">{formatMoney(order.total)}</span>
        </div>
        <div className="flex justify-between text-xs text-ink2 mt-1">
          <span>Entrega</span>
          <span className="font-semibold text-ink">
            {order.delivery_method === "retirar" ? "Retirar" : "Receber"}
          </span>
        </div>
      </div>

      {waNumber && (
        <a
          href={`https://wa.me/${waNumber}?text=${waText}`}
          target="_blank"
          className="btn-primary w-full mt-6 inline-flex"
        >
          Falar no WhatsApp
        </a>
      )}

      <Link href="/" className="block text-xs text-ink2 underline mt-4">
        Voltar ao festival
      </Link>
    </main>
  );
}
