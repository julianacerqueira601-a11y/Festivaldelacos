"use client";
import { useState } from "react";
import { supabaseBrowser } from "@/lib/supabaseClient";
import { useRouter } from "next/navigation";

export default function AdminLoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function handleLogin() {
    setLoading(true);
    setError(null);
    const supabase = supabaseBrowser();
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      setError("E-mail ou senha inválidos.");
      return;
    }
    router.push("/admin");
    router.refresh();
  }

  return (
    <main className="px-6 pt-20 max-w-sm mx-auto">
      <h1 className="font-display text-2xl text-center">Painel administrativo</h1>
      <p className="text-ink2 text-sm text-center mt-1">Festival de Laços</p>

      <div className="flex flex-col gap-3 mt-8">
        <input
          type="email"
          placeholder="E-mail"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="input"
        />
        <input
          type="password"
          placeholder="Senha"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="input"
        />
        {error && <p className="text-red-600 text-xs">{error}</p>}
        <button onClick={handleLogin} disabled={loading} className="btn-primary w-full mt-2">
          {loading ? "Entrando..." : "Entrar"}
        </button>
      </div>

      <style jsx global>{`
        .input {
          width: 100%;
          border: 1px solid rgba(0,0,0,0.1);
          border-radius: 10px;
          padding: 12px 14px;
          font-size: 14px;
          background: white;
        }
      `}</style>
    </main>
  );
}
