import { supabaseAdmin } from "@/lib/supabaseAdmin";
import StockTable from "@/components/StockTable";
import NewProductForm from "@/components/NewProductForm";

export const revalidate = 0;

export default async function EstoquePage() {
  const supabase = supabaseAdmin();
  const { data: products } = await supabase
    .from("products_with_availability")
    .select("*")
    .order("code");

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h1 className="font-display text-xl">Estoque</h1>
      </div>
      <NewProductForm />
      <StockTable products={products ?? []} />
    </div>
  );
}
