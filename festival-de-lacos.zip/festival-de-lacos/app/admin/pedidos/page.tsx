import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { formatMoney, pad4 } from "@/lib/format";
import { ORDER_STATUS_LABELS } from "@/lib/types";
import OrderActions from "@/components/OrderActions";

export const revalidate = 0;

export default async function PedidosPage() {
  const supabase = supabaseAdmin();
  const { data: orders } = await supabase
    .from("orders")
    .select("id, order_number, status, total, delivery_method, created_at, customers(name, whatsapp), order_items(quantity, unit_price, products(name, color, code))")
    .order("created_at", { ascending: false })
    .limit(100);

  return (
    <div>
      <h1 className="font-display text-xl mb-4">Pedidos</h1>
      <div className="flex flex-col gap-3">
        {orders?.map((o: any) => (
          <div key={o.id} className="card p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="font-display text-sm">#{pad4(o.order_number)} — {o.customers?.name}</p>
                <p className="text-xs text-ink2">{o.customers?.whatsapp}</p>
              </div>
              <span className="text-[10px] font-bold uppercase bg-bgalt px-2 py-1 rounded-full">
                {ORDER_STATUS_LABELS[o.status as keyof typeof ORDER_STATUS_LABELS]}
              </span>
            </div>

            <ul className="text-xs text-ink2 mt-2 space-y-0.5">
              {o.order_items?.map((it: any, idx: number) => (
                <li key={idx}>
                  {it.quantity}× {it.products?.name} ({it.products?.color}) — {formatMoney(it.unit_price * it.quantity)}
                </li>
              ))}
            </ul>

            <div className="flex justify-between text-sm mt-2 pt-2 border-t border-black/5">
              <span className="text-ink2 text-xs">{o.delivery_method === "retirar" ? "Retirar" : "Receber"}</span>
              <span className="font-bold">{formatMoney(o.total)}</span>
            </div>

            <OrderActions orderId={o.id} status={o.status} />
          </div>
        ))}
        {(!orders || orders.length === 0) && (
          <p className="text-center text-ink2 text-sm py-10">Nenhum pedido ainda.</p>
        )}
      </div>
    </div>
  );
}
