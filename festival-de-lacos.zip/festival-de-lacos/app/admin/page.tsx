import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { formatMoney } from "@/lib/format";

export const revalidate = 0;

export default async function AdminDashboard() {
  const supabase = supabaseAdmin();

  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);

  const [{ data: paidToday }, { data: paidAll }, { count: ordersCount }, { count: awaitingCount }, { data: products }] =
    await Promise.all([
      supabase.from("orders").select("total").eq("status", "pago").gte("updated_at", startOfToday.toISOString()),
      supabase.from("orders").select("total").in("status", ["pago", "separando", "pronto_para_retirada", "em_entrega", "entregue"]),
      supabase.from("orders").select("*", { count: "exact", head: true }),
      supabase.from("orders").select("*", { count: "exact", head: true }).in("status", ["reservado", "aguardando_pagamento", "pagamento_informado"]),
      supabase.from("products").select("stock_total, stock_reserved, stock_sold"),
    ]);

  const salesToday = (paidToday ?? []).reduce((s, o) => s + Number(o.total), 0);
  const totalSold = (paidAll ?? []).reduce((s, o) => s + Number(o.total), 0);
  const productsSold = (products ?? []).reduce((s, p) => s + p.stock_sold, 0);
  const productsAvailable = (products ?? []).reduce((s, p) => s + (p.stock_total - p.stock_reserved - p.stock_sold), 0);
  const productsReserved = (products ?? []).reduce((s, p) => s + p.stock_reserved, 0);

  const cards = [
    { label: "Vendas hoje", value: formatMoney(salesToday) },
    { label: "Total vendido", value: formatMoney(totalSold) },
    { label: "Pedidos", value: ordersCount ?? 0 },
    { label: "Aguardando pagamento", value: awaitingCount ?? 0 },
    { label: "Produtos vendidos", value: productsSold },
    { label: "Produtos disponíveis", value: productsAvailable },
    { label: "Produtos reservados", value: productsReserved },
  ];

  return (
    <div>
      <h1 className="font-display text-xl mb-4">Festival de Laços</h1>
      <div className="grid grid-cols-2 gap-3">
        {cards.map((c) => (
          <div key={c.label} className="card p-4">
            <p className="text-[11px] text-ink2 font-semibold uppercase tracking-wide">{c.label}</p>
            <p className="font-display text-2xl mt-1">{c.value}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
