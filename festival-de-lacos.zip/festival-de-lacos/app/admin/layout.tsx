import Link from "next/link";
import LogoutButton from "@/components/LogoutButton";

const NAV = [
  { href: "/admin", label: "Dashboard" },
  { href: "/admin/pedidos", label: "Pedidos" },
  { href: "/admin/clientes", label: "Clientes" },
  { href: "/admin/estoque", label: "Estoque" },
  { href: "/admin/configuracoes", label: "Configurações" },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-bgalt">
      <header className="bg-ink text-bg px-5 py-4 flex items-center justify-between sticky top-0 z-10">
        <span className="font-display text-lg">🎀 Painel</span>
        <LogoutButton />
      </header>
      <nav className="flex overflow-x-auto gap-1 px-3 py-2 bg-white border-b border-black/5 sticky top-[57px] z-10">
        {NAV.map((n) => (
          <Link
            key={n.href}
            href={n.href}
            className="text-xs font-semibold px-3 py-2 rounded-full whitespace-nowrap hover:bg-bgalt"
          >
            {n.label}
          </Link>
        ))}
      </nav>
      <main className="px-4 py-5 max-w-3xl mx-auto">{children}</main>
    </div>
  );
}
