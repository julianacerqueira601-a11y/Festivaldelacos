import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { formatMoney } from "@/lib/format";

export const revalidate = 0;

export default async function ClientesPage() {
  const supabase = supabaseAdmin();
  const { data: customers } = await supabase
    .from("customers")
    .select("id, name, whatsapp, neighborhood, created_at, orders(total, status, created_at)");

  const rows = (customers ?? []).map((c: any) => {
    const paidOrders = c.orders.filter((o: any) => o.status !== "cancelado" && o.status !== "expirado");
    const total = paidOrders.reduce((s: number, o: any) => s + Number(o.total), 0);
    const last = c.orders.sort((a: any, b: any) => b.created_at.localeCompare(a.created_at))[0];
    return { ...c, orderCount: c.orders.length, total, lastOrder: last?.created_at };
  });

  return (
    <div>
      <h1 className="font-display text-xl mb-4">Clientes</h1>
      <div className="flex flex-col gap-2">
        {rows.map((c) => (
          <div key={c.id} className="card p-3">
            <p className="font-display text-sm">{c.name}</p>
            <p className="text-xs text-ink2">{c.whatsapp}{c.neighborhood ? ` · ${c.neighborhood}` : ""}</p>
            <div className="flex justify-between text-xs mt-2 pt-2 border-t border-black/5">
              <span className="text-ink2">{c.orderCount} pedido{c.orderCount !== 1 ? "s" : ""}</span>
              <span className="font-semibold">{formatMoney(c.total)}</span>
            </div>
          </div>
        ))}
        {rows.length === 0 && <p className="text-center text-ink2 text-sm py-10">Nenhum cliente ainda.</p>}
      </div>
    </div>
  );
}
