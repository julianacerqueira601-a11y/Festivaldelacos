import { supabaseAdmin } from "@/lib/supabaseAdmin";
import SettingsForm from "@/components/SettingsForm";

export const revalidate = 0;

export default async function ConfiguracoesPage() {
  const supabase = supabaseAdmin();
  const { data: settings } = await supabase.from("settings").select("*").eq("id", 1).single();

  return (
    <div>
      <h1 className="font-display text-xl mb-4">Configurações</h1>
      <SettingsForm initial={settings} />
    </div>
  );
}
