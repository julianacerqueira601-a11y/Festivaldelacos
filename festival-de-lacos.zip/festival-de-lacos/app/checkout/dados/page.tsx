"use client";
import { useCart } from "@/lib/cartStore";
import { formatMoney } from "@/lib/format";
import { useRouter } from "next/navigation";
import { useState } from "react";
import Link from "next/link";
import type { DeliveryMethod } from "@/lib/types";

export default function DadosPage() {
  const items = useCart((s) => s.items);
  const total = useCart((s) => s.total());
  const router = useRouter();

  const [name, setName] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [method, setMethod] = useState<DeliveryMethod>("retirar");
  const [street, setStreet] = useState("");
  const [number, setNumber] = useState("");
  const [complement, setComplement] = useState("");
  const [neighborhood, setNeighborhood] = useState("");
  const [reference, setReference] = useState("");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit() {
    if (!name || !whatsapp) {
      setError("Preencha nome e WhatsApp.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/reservations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: items.map((i) => ({ productId: i.productId, quantity: i.quantity })),
          customer: { name, whatsapp, neighborhood },
          deliveryMethod: method,
          address:
            method === "receber"
              ? { street, number, complement, neighborhood, reference }
              : null,
          notes,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        // estoque mudou entre o cliente ver o produto e finalizar —
        // isso é o RLS/função atômica do banco barrando overselling
        setError(data.error ?? "Não foi possível reservar. Algum item pode ter esgotado.");
        setLoading(false);
        return;
      }
      useCart.getState().clear();
      router.push(`/checkout/pix?orderId=${data.orderId}`);
    } catch (e) {
      setError("Erro de conexão. Tente novamente.");
      setLoading(false);
    }
  }

  return (
    <main className="px-5 pt-6 pb-10">
      <Link href="/carrinho" className="text-xs text-ink2 underline">
        ← Voltar ao carrinho
      </Link>
      <h1 className="font-display text-2xl mt-3 mb-5">Seus dados</h1>

      <div className="flex flex-col gap-3">
        <Field label="Nome completo">
          <input value={name} onChange={(e) => setName(e.target.value)} className="input" />
        </Field>
        <Field label="WhatsApp">
          <input
            value={whatsapp}
            onChange={(e) => setWhatsapp(e.target.value)}
            placeholder="(00) 00000-0000"
            className="input"
          />
        </Field>

        <p className="text-xs font-semibold text-ink2 mt-2">Como deseja receber?</p>
        <div className="flex gap-2">
          <button
            onClick={() => setMethod("retirar")}
            className={`flex-1 py-3 rounded-xl2 border text-sm font-semibold ${method === "retirar" ? "bg-ink text-bg border-ink" : "border-black/10"}`}
          >
            Retirar
          </button>
          <button
            onClick={() => setMethod("receber")}
            className={`flex-1 py-3 rounded-xl2 border text-sm font-semibold ${method === "receber" ? "bg-ink text-bg border-ink" : "border-black/10"}`}
          >
            Receber
          </button>
        </div>

        {method === "receber" && (
          <div className="grid grid-cols-2 gap-2 mt-1">
            <Field label="Rua" full>
              <input value={street} onChange={(e) => setStreet(e.target.value)} className="input" />
            </Field>
            <Field label="Número">
              <input value={number} onChange={(e) => setNumber(e.target.value)} className="input" />
            </Field>
            <Field label="Complemento">
              <input value={complement} onChange={(e) => setComplement(e.target.value)} className="input" />
            </Field>
            <Field label="Bairro" full>
              <input value={neighborhood} onChange={(e) => setNeighborhood(e.target.value)} className="input" />
            </Field>
            <Field label="Referência" full>
              <input value={reference} onChange={(e) => setReference(e.target.value)} className="input" />
            </Field>
          </div>
        )}

        <Field label="Observação do pedido (opcional)">
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Ex: pode entregar depois das 18h."
            className="input"
            rows={2}
          />
        </Field>
      </div>

      {error && <p className="text-red-600 text-xs mt-3">{error}</p>}

      <div className="mt-6 flex justify-between text-sm">
        <span className="text-ink2">Total</span>
        <span className="font-bold text-base">{formatMoney(total)}</span>
      </div>

      <button onClick={handleSubmit} disabled={loading} className="btn-primary w-full mt-4">
        {loading ? "Reservando..." : "Reservar e continuar"}
      </button>

      <style jsx global>{`
        .input {
          width: 100%;
          border: 1px solid rgba(0,0,0,0.1);
          border-radius: 10px;
          padding: 10px 12px;
          font-size: 13.5px;
          background: white;
        }
      `}</style>
    </main>
  );
}

function Field({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <label className={`flex flex-col gap-1 text-xs font-semibold text-ink2 ${full ? "col-span-2" : ""}`}>
      {label}
      {children}
    </label>
  );
}
