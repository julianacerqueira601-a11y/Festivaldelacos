"use client";
import { Suspense, useEffect, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { formatMoney, pad4 } from "@/lib/format";

type OrderInfo = {
  orderNumber: number;
  total: number;
  reservedUntil: string;
  status: string;
};

export default function PixPage() {
  return (
    <Suspense fallback={<main className="px-5 pt-10 text-center text-ink2 text-sm">Carregando...</main>}>
      <PixPageContent />
    </Suspense>
  );
}

function PixPageContent() {
  const params = useSearchParams();
  const router = useRouter();
  const orderId = params.get("orderId");

  const [order, setOrder] = useState<OrderInfo | null>(null);
  const [pix, setPix] = useState<{ key: string; receiver: string; qrUrl: string | null } | null>(null);
  const [secondsLeft, setSecondsLeft] = useState<number | null>(null);
  const [confirming, setConfirming] = useState(false);

  useEffect(() => {
    if (!orderId) return;
    fetch(`/api/orders/${orderId}`)
      .then((r) => r.json())
      .then((data) => {
        setOrder(data.order);
        setPix(data.pix);
      });
  }, [orderId]);

  useEffect(() => {
    if (!order) return;
    const tick = () => {
      const diff = Math.max(0, Math.floor((new Date(order.reservedUntil).getTime() - Date.now()) / 1000));
      setSecondsLeft(diff);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [order]);

  async function handleConfirm() {
    if (!orderId) return;
    setConfirming(true);
    await fetch(`/api/orders/${orderId}/inform-payment`, { method: "POST" });
    router.push(`/pedido/${orderId}`);
  }

  if (!order || !pix) {
    return <main className="px-5 pt-10 text-center text-ink2 text-sm">Carregando...</main>;
  }

  const expired = secondsLeft === 0;
  const mm = String(Math.floor((secondsLeft ?? 0) / 60)).padStart(2, "0");
  const ss = String((secondsLeft ?? 0) % 60).padStart(2, "0");

  return (
    <main className="px-5 pt-6 pb-10 text-center">
      <h1 className="font-display text-2xl">Pagamento via Pix</h1>
      <p className="text-ink2 text-sm mt-1">Pedido #{pad4(order.orderNumber)}</p>

      {!expired ? (
        <div className="mt-4 inline-block bg-amarelo/40 rounded-full px-4 py-2 text-sm font-semibold">
          ⏱️ Seu pedido está reservado por {mm}:{ss}
        </div>
      ) : (
        <div className="mt-4 inline-block bg-red-100 text-red-700 rounded-full px-4 py-2 text-sm font-semibold">
          Tempo esgotado — os produtos foram liberados
        </div>
      )}

      <p className="mt-6 text-sm text-ink2">Valor do pedido</p>
      <p className="font-display text-3xl mt-1">{formatMoney(order.total)}</p>

      {pix.qrUrl ? (
        <img src={pix.qrUrl} alt="QR Code Pix" className="w-48 h-48 mx-auto mt-6 rounded-xl2 border" />
      ) : (
        <div className="w-48 h-48 mx-auto mt-6 rounded-xl2 border border-dashed flex items-center justify-center text-xs text-ink2 p-4">
          [QR CODE PIX A DEFINIR]
        </div>
      )}

      <div className="card mt-4 p-3 text-left">
        <p className="text-[11px] text-ink2 font-semibold">Chave Pix</p>
        <div className="flex items-center justify-between mt-1">
          <span className="text-sm break-all">{pix.key}</span>
          <button
            onClick={() => navigator.clipboard.writeText(pix.key)}
            className="btn-outline !py-1.5 !px-3 !text-[11px] flex-shrink-0 ml-2"
          >
            Copiar
          </button>
        </div>
        <p className="text-[11px] text-ink2 mt-2">Recebedor: {pix.receiver}</p>
      </div>

      <ol className="text-left text-xs text-ink2 mt-5 space-y-1.5 list-decimal list-inside">
        <li>Copie a chave Pix ou escaneie o QR Code.</li>
        <li>Faça o pagamento no seu banco.</li>
        <li>Depois, clique em "Já fiz o pagamento".</li>
      </ol>

      <button
        onClick={handleConfirm}
        disabled={expired || confirming}
        className="btn-primary w-full mt-6 disabled:opacity-40"
      >
        {confirming ? "Enviando..." : "Já fiz o pagamento"}
      </button>
    </main>
  );
}
