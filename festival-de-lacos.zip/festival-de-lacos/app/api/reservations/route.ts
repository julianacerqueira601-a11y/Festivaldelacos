import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

// POST /api/reservations
// Cria cliente (se novo), cria o pedido, e chama a função atômica
// reserve_products() no banco — que é quem realmente garante que
// não vendemos o mesmo par duas vezes.
export async function POST(req: NextRequest) {
  const body = await req.json();
  const { items, customer, deliveryMethod, address, notes } = body;

  if (!items?.length || !customer?.name || !customer?.whatsapp) {
    return NextResponse.json({ error: "Dados incompletos." }, { status: 400 });
  }

  const supabase = supabaseAdmin();

  // busca/settings: tempo de reserva e preços atuais (nunca confie no preço do carrinho do cliente)
  const { data: settings } = await supabase
    .from("settings")
    .select("reservation_minutes")
    .eq("id", 1)
    .single();
  const reservationMinutes = settings?.reservation_minutes ?? 10;

  const { data: productsNow, error: productsError } = await supabase
    .from("products")
    .select("id, price, is_active")
    .in(
      "id",
      items.map((i: any) => i.productId)
    );

  if (productsError || !productsNow) {
    return NextResponse.json({ error: "Erro ao consultar produtos." }, { status: 500 });
  }

  // 1) upsert do cliente pelo whatsapp
  const { data: existingCustomer } = await supabase
    .from("customers")
    .select("id")
    .eq("whatsapp", customer.whatsapp)
    .maybeSingle();

  let customerId = existingCustomer?.id;
  if (!customerId) {
    const { data: newCustomer, error: customerError } = await supabase
      .from("customers")
      .insert({ name: customer.name, whatsapp: customer.whatsapp, neighborhood: customer.neighborhood ?? null })
      .select("id")
      .single();
    if (customerError) {
      return NextResponse.json({ error: "Erro ao salvar cliente." }, { status: 500 });
    }
    customerId = newCustomer.id;
  }

  // 2) calcula total com preço oficial do banco (não confia no preço do cliente)
  const total = items.reduce((sum: number, i: any) => {
    const p = productsNow.find((pp) => pp.id === i.productId);
    return sum + (p?.price ?? 0) * i.quantity;
  }, 0);

  const reservedUntil = new Date(Date.now() + reservationMinutes * 60_000).toISOString();

  // 3) cria o pedido em status "reservado"
  const { data: order, error: orderError } = await supabase
    .from("orders")
    .insert({
      customer_id: customerId,
      status: "reservado",
      delivery_method: deliveryMethod,
      address_street: address?.street ?? null,
      address_number: address?.number ?? null,
      address_complement: address?.complement ?? null,
      address_neighborhood: address?.neighborhood ?? null,
      address_reference: address?.reference ?? null,
      notes: notes ?? null,
      total,
      reserved_until: reservedUntil,
    })
    .select("id, order_number")
    .single();

  if (orderError || !order) {
    return NextResponse.json({ error: "Erro ao criar pedido." }, { status: 500 });
  }

  // 4) TENTA reservar o estoque de forma atômica.
  // Se falhar (alguém levou o último par entre o catálogo e agora),
  // desfazemos o pedido e avisamos o cliente.
  const { error: reserveError } = await supabase.rpc("reserve_products", {
    items: items.map((i: any) => ({ product_id: i.productId, quantity: i.quantity })),
    p_minutes: reservationMinutes,
  });

  if (reserveError) {
    await supabase.from("orders").delete().eq("id", order.id);
    return NextResponse.json(
      { error: "Um dos itens acabou de esgotar. Volte ao catálogo e confira a quantidade disponível." },
      { status: 409 }
    );
  }

  // 5) grava os itens do pedido com o preço oficial
  const orderItems = items.map((i: any) => {
    const p = productsNow.find((pp) => pp.id === i.productId)!;
    return {
      order_id: order.id,
      product_id: i.productId,
      quantity: i.quantity,
      unit_price: p.price,
      subtotal: p.price * i.quantity,
    };
  });
  await supabase.from("order_items").insert(orderItems);

  // 6) cria o registro de pagamento (aguardando)
  await supabase.from("payments").insert({
    order_id: order.id,
    method: "pix",
    amount: total,
    status: "aguardando",
  });

  await supabase.from("inventory_movements").insert({
    order_id: order.id,
    event: "pedido_reservado",
  });

  return NextResponse.json({ orderId: order.id, orderNumber: order.order_number });
}
