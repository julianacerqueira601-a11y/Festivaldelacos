import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

// POST /api/orders/:id/inform-payment
// Cliente clicou em "Já fiz o pagamento". Isso NÃO confirma a venda —
// só muda o status pra "pagamento_informado", pro admin conferir.
// A reserva de estoque continua valendo até o admin confirmar
// ou até reserved_until passar (o cron cuida disso).
export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  const supabase = supabaseAdmin();

  const { data: order } = await supabase
    .from("orders")
    .select("id, status, reserved_until")
    .eq("id", params.id)
    .single();

  if (!order) {
    return NextResponse.json({ error: "Pedido não encontrado." }, { status: 404 });
  }

  if (new Date(order.reserved_until) < new Date()) {
    return NextResponse.json({ error: "A reserva deste pedido já expirou." }, { status: 409 });
  }

  await supabase.from("orders").update({ status: "pagamento_informado" }).eq("id", order.id);
  await supabase.from("payments").update({ status: "informado", informed_at: new Date().toISOString() }).eq("order_id", order.id);
  await supabase.from("inventory_movements").insert({ order_id: order.id, event: "pagamento_informado" });

  return NextResponse.json({ ok: true });
}
