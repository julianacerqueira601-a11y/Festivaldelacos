import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

// GET /api/orders/:id — dados públicos pra tela de Pix e confirmação.
// Não expõe endereço/telefone de outros pedidos: só o que o próprio
// pedido precisa mostrar pra quem tem o orderId em mãos.
export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const supabase = supabaseAdmin();

  const { data: order } = await supabase
    .from("orders")
    .select("order_number, total, reserved_until, status")
    .eq("id", params.id)
    .single();

  if (!order) {
    return NextResponse.json({ error: "Pedido não encontrado." }, { status: 404 });
  }

  const { data: settings } = await supabase
    .from("settings")
    .select("pix_key, pix_receiver_name, pix_qr_code_url")
    .eq("id", 1)
    .single();

  return NextResponse.json({
    order: {
      orderNumber: order.order_number,
      total: order.total,
      reservedUntil: order.reserved_until,
      status: order.status,
    },
    pix: {
      key: settings?.pix_key ?? "[CHAVE PIX A DEFINIR]",
      receiver: settings?.pix_receiver_name ?? "[NOME A DEFINIR]",
      qrUrl: settings?.pix_qr_code_url ?? null,
    },
  });
}
