import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

async function requireAdmin() {
  const cookieStore = cookies();
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    { cookies: { get: (n) => cookieStore.get(n)?.value } }
  );
  const { data: { session } } = await supabase.auth.getSession();
  return session;
}

// POST /api/admin/orders/:id/confirm-payment
// Único caminho que move estoque de "reservado" pra "vendido" de
// forma definitiva. Exige sessão de admin válida (cookie do Supabase
// Auth, checado pelo middleware + de novo aqui).
export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "Não autorizado." }, { status: 401 });

  const supabase = supabaseAdmin();
  const { error } = await supabase.rpc("confirm_order_payment", {
    p_order_id: params.id,
    p_confirmed_by: "admin",
  });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true });
}
