import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

async function requireAdmin() {
  const cookieStore = cookies();
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    { cookies: { get: (n) => cookieStore.get(n)?.value } }
  );
  const { data: { session } } = await supabase.auth.getSession();
  return session;
}

const ALLOWED = ["separando", "pronto_para_retirada", "em_entrega", "entregue", "cancelado"];

// POST /api/admin/orders/:id/status  { status: "separando" | ... }
export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "Não autorizado." }, { status: 401 });

  const { status } = await req.json();
  if (!ALLOWED.includes(status)) {
    return NextResponse.json({ error: "Status inválido." }, { status: 400 });
  }

  const supabase = supabaseAdmin();

  // cancelar um pedido ainda não pago devolve o estoque reservado
  if (status === "cancelado") {
    await supabase.rpc("release_reservation", { p_order_id: params.id });
  }

  await supabase.from("orders").update({ status, updated_at: new Date().toISOString() }).eq("id", params.id);
  await supabase.from("inventory_movements").insert({
    order_id: params.id,
    event: status === "cancelado" ? "pedido_cancelado" : status === "entregue" ? "pedido_entregue" : "status_alterado",
    detail: { status },
  });

  return NextResponse.json({ ok: true });
}
