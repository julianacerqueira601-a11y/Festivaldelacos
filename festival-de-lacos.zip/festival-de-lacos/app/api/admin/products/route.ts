import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

async function requireAdmin() {
  const cookieStore = cookies();
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    { cookies: { get: (n) => cookieStore.get(n)?.value } }
  );
  const { data: { session } } = await supabase.auth.getSession();
  return session;
}

// POST /api/admin/products — cria um novo produto
export async function POST(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "Não autorizado." }, { status: 401 });

  const body = await req.json();
  const supabase = supabaseAdmin();

  const { data, error } = await supabase
    .from("products")
    .insert({
      code: body.code,
      name: body.name,
      color: body.color,
      category: body.category ?? "Laços",
      size: body.size ?? null,
      price: body.price,
      stock_total: body.stock,
      photo_url: body.photoUrl ?? null,
    })
    .select("id")
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 400 });

  await supabase.from("inventory_movements").insert({
    product_id: data.id,
    event: "produto_criado",
  });

  return NextResponse.json({ id: data.id });
}
