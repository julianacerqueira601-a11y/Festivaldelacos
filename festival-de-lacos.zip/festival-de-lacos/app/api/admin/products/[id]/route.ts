import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

async function requireAdmin() {
  const cookieStore = cookies();
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    { cookies: { get: (n) => cookieStore.get(n)?.value } }
  );
  const { data: { session } } = await supabase.auth.getSession();
  return session;
}

// PATCH /api/admin/products/:id — edita produto (dados, preço, estoque, ativo/inativo)
export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "Não autorizado." }, { status: 401 });

  const body = await req.json();
  const supabase = supabaseAdmin();

  // se for só alterar estoque total, valida que não fica menor que reservado+vendido
  if (body.stock_total !== undefined) {
    const { data: current } = await supabase
      .from("products")
      .select("stock_reserved, stock_sold")
      .eq("id", params.id)
      .single();
    if (current && body.stock_total < current.stock_reserved + current.stock_sold) {
      return NextResponse.json(
        { error: "Novo estoque não pode ser menor que o já reservado/vendido." },
        { status: 400 }
      );
    }
  }

  const { error } = await supabase
    .from("products")
    .update({ ...body, updated_at: new Date().toISOString() })
    .eq("id", params.id);

  if (error) return NextResponse.json({ error: error.message }, { status: 400 });

  await supabase.from("inventory_movements").insert({
    product_id: params.id,
    event: "estoque_alterado",
    detail: body,
  });

  return NextResponse.json({ ok: true });
}
