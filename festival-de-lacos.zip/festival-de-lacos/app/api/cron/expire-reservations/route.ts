import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

// GET /api/cron/expire-reservations
// A Vercel chama essa rota a cada 1 minuto (ver vercel.json).
// Protegida por CRON_SECRET pra ninguém de fora conseguir chamar.
export async function GET(req: NextRequest) {
  const auth = req.headers.get("authorization");
  if (auth !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Não autorizado." }, { status: 401 });
  }

  const supabase = supabaseAdmin();
  const { data, error } = await supabase.rpc("expire_stale_reservations");

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ expired: data ?? 0 });
}
