import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Festival de Laços",
  description: "Modelos exclusivos • Quantidades limitadas",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="font-sans min-h-screen">
        <div className="max-w-lg mx-auto min-h-screen bg-bg shadow-xl">{children}</div>
      </body>
    </html>
  );
}
