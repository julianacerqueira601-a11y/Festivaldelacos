import { supabaseAdmin } from "@/lib/supabaseAdmin";
import ProductCard from "@/components/ProductCard";
import CartBarClient from "@/components/CartBarClient";
import type { Product } from "@/lib/types";

export const revalidate = 0; // sempre buscar estoque atual, nunca cache

export default async function FestivalPage() {
  // leitura pública: usamos o client admin aqui só porque é Server
  // Component (roda no servidor); o browser nunca vê a service key.
  const supabase = supabaseAdmin();

  const { data: products } = await supabase
    .from("products_with_availability")
    .select("*")
    .eq("is_active", true)
    .order("code");

  const { data: settingsRows } = await supabase
    .from("settings")
    .select("festival_name, festival_description, whatsapp_number")
    .eq("id", 1)
    .single();

  const shareText = encodeURIComponent(
    `🎀 O ${settingsRows?.festival_name ?? "Festival de Laços"} está aberto!\n\nTem vários modelos disponíveis e as quantidades são limitadas.\n\nConfira os modelos e garanta o seu:\n[LINK DO FESTIVAL]`
  );

  return (
    <main className="pb-28">
      <header className="px-5 pt-8 pb-6 text-center">
        <h1 className="font-display text-3xl">
          🎀 {settingsRows?.festival_name ?? "Festival de Laços"}
        </h1>
        <p className="text-ink2 text-sm mt-1">
          {settingsRows?.festival_description ?? "Modelos exclusivos • Quantidades limitadas"}
        </p>
        <a
          href={`https://wa.me/?text=${shareText}`}
          target="_blank"
          className="btn-outline mt-4 !py-2.5 !text-xs inline-flex"
        >
          Compartilhar no WhatsApp
        </a>
      </header>

      <section className="px-4 grid grid-cols-2 gap-3">
        {(products as Product[] | null)?.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
        {(!products || products.length === 0) && (
          <p className="col-span-2 text-center text-ink2 text-sm py-10">
            Nenhum produto disponível no momento.
          </p>
        )}
      </section>

      <CartBar />
    </main>
  );
}

function CartBar() {
  return (
    <div className="fixed bottom-0 left-0 right-0 max-w-lg mx-auto">
      <CartBarClient />
    </div>
  );
}
