"use client";
import { useCart } from "@/lib/cartStore";
import { formatMoney } from "@/lib/format";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function CarrinhoPage() {
  const items = useCart((s) => s.items);
  const setQuantity = useCart((s) => s.setQuantity);
  const remove = useCart((s) => s.remove);
  const total = useCart((s) => s.total());
  const router = useRouter();

  return (
    <main className="px-5 pt-6 pb-32">
      <Link href="/" className="text-xs text-ink2 underline">
        ← Voltar ao festival
      </Link>
      <h1 className="font-display text-2xl mt-3 mb-5">Seu carrinho</h1>

      {items.length === 0 && (
        <p className="text-ink2 text-sm text-center py-16">
          Seu carrinho está vazio. <br />
          <Link href="/" className="underline">
            Ver os laços disponíveis
          </Link>
        </p>
      )}

      <div className="flex flex-col gap-3">
        {items.map((item) => (
          <div key={item.productId} className="card p-3 flex gap-3">
            <div className="w-16 h-16 rounded-lg bg-bgalt flex-shrink-0" />
            <div className="flex-1">
              <p className="font-display text-sm">{item.name}</p>
              <p className="text-xs text-ink2">{item.color}</p>
              <div className="flex items-center justify-between mt-2">
                <div className="flex items-center border border-black/10 rounded-full">
                  <button
                    className="w-8 h-8 text-sm"
                    onClick={() => setQuantity(item.productId, item.quantity - 1)}
                  >
                    −
                  </button>
                  <span className="w-6 text-center text-sm font-semibold">{item.quantity}</span>
                  <button
                    className="w-8 h-8 text-sm"
                    onClick={() => setQuantity(item.productId, item.quantity + 1)}
                    disabled={item.quantity >= item.maxAvailable}
                  >
                    +
                  </button>
                </div>
                <span className="font-bold text-sm">
                  {formatMoney(item.price * item.quantity)}
                </span>
              </div>
              <button
                onClick={() => remove(item.productId)}
                className="text-[11px] text-ink2 underline mt-1"
              >
                Remover
              </button>
            </div>
          </div>
        ))}
      </div>

      {items.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 max-w-lg mx-auto bg-bg border-t border-black/5 p-4">
          <div className="flex justify-between text-sm mb-3">
            <span className="text-ink2">Total</span>
            <span className="font-bold text-base">{formatMoney(total)}</span>
          </div>
          <button onClick={() => router.push("/checkout/dados")} className="btn-primary w-full">
            Continuar
          </button>
        </div>
      )}
    </main>
  );
}
