import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { formatMoney } from "@/lib/format";
import Link from "next/link";
import Image from "next/image";
import AddToCartButton from "@/components/AddToCartButton";
import type { Product } from "@/lib/types";

export const revalidate = 0;

export default async function ProdutoPage({ params }: { params: { id: string } }) {
  const supabase = supabaseAdmin();
  const { data: product } = await supabase
    .from("products_with_availability")
    .select("*")
    .eq("id", params.id)
    .single();

  if (!product) {
    return <main className="px-5 pt-10 text-center text-ink2 text-sm">Produto não encontrado.</main>;
  }

  const p = product as Product;
  const esgotado = p.availability_label === "esgotado";
  const ultimoPar = p.availability_label === "ultimo_par";

  return (
    <main className="pb-10">
      <Link href="/" className="block px-5 pt-5 text-xs text-ink2 underline">
        ← Voltar ao festival
      </Link>

      <div className="relative aspect-square bg-bgalt mt-4">
        {p.photo_url ? (
          <Image src={p.photo_url} alt={p.name} fill className="object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-ink2 text-xs">
            [FOTO DO PRODUTO]
          </div>
        )}
      </div>

      <div className="px-5 pt-5">
        <span className="text-[11px] tracking-wider text-ink2 font-semibold uppercase">{p.code}</span>
        <h1 className="font-display text-2xl mt-1">{p.name}</h1>
        <p className="text-ink2 text-sm">{p.color}{p.size ? ` · ${p.size}` : ""}</p>
        <p className="font-display text-2xl mt-3">{formatMoney(p.price)}</p>

        <div className="mt-2">
          {esgotado && <span className="text-sm font-semibold text-red-600">🔴 Esgotado</span>}
          {ultimoPar && <span className="text-sm font-semibold text-amber-600">🟠 Último par</span>}
          {!esgotado && !ultimoPar && (
            <span className="text-sm font-semibold text-green-700">
              🟢 {p.stock_available} pares disponíveis
            </span>
          )}
        </div>

        {p.description && <p className="text-sm text-ink2 mt-4 leading-relaxed">{p.description}</p>}

        <AddToCartButton product={p} />
      </div>
    </main>
  );
}
