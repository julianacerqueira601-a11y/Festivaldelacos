# 🎀 Festival de Laços

Sistema de vendas por festival (WhatsApp → catálogo → reserva → Pix → confirmação),
com painel administrativo, controle de estoque em tempo real e reserva temporária
sem overselling.

## Stack

- **Next.js 14** (App Router) + TypeScript + Tailwind — frontend e API num só projeto
- **Supabase** — banco Postgres, autenticação do admin, storage das fotos
- **Vercel** — hospedagem (grátis) + Cron Job pra expirar reservas vencidas

## Passo a passo para colocar no ar

### 1. Criar o projeto no Supabase
1. Crie uma conta em supabase.com e um novo projeto (grátis).
2. Vá em **SQL Editor** e rode, nesta ordem:
   - `db/schema.sql`
   - `db/functions.sql`
   - `db/seed.sql` (cria os 5 produtos de teste — pode apagar depois)
3. Vá em **Storage** e crie um bucket público chamado `products` (pra subir as fotos dos laços).
4. Vá em **Authentication → Users** e crie o usuário do admin (seu e-mail e uma senha) — é com esse login que você entra em `/admin`.
5. Vá em **Project Settings → API** e copie: `Project URL`, `anon public key` e `service_role key`.

### 2. Configurar o projeto
1. Copie `.env.example` para `.env.local` e preencha com os valores do passo anterior.
2. `CRON_SECRET`: invente uma senha aleatória qualquer.

### 3. Rodar localmente (opcional, pra testar antes)
```
npm install
npm run dev
```
Abra `http://localhost:3000` (catálogo) e `http://localhost:3000/admin` (painel).

### 4. Publicar
1. Suba este projeto pro GitHub (crie um repositório novo e faça push desta pasta).
2. Em vercel.com, importe o repositório.
3. Em **Environment Variables**, cole as mesmas variáveis do `.env.local`.
4. Deploy. A Vercel já vai configurar o Cron Job sozinha (está em `vercel.json`).
5. Pronto — o link que a Vercel te der é o que você compartilha no grupo do WhatsApp.

### 5. Configurar o festival
Entre em `/admin/configuracoes` e preencha: chave Pix, nome do recebedor, QR Code
(pode subir a imagem do QR no bucket `products` do Storage e colar a URL aqui),
tempo de reserva, número de WhatsApp e a mensagem de confirmação.

Depois vá em `/admin/estoque` e cadastre os laços reais (pode apagar os 5 de teste).

## Como funciona a reserva (pra não vender o mesmo par duas vezes)

Toda reserva passa pela função `reserve_products()` no banco (`db/functions.sql`),
que trava a linha do produto durante a transação. Se duas pessoas tentarem levar
o último par ao mesmo tempo, o Postgres processa uma de cada vez — a segunda
recebe erro de estoque insuficiente e o pedido dela nem chega a ser criado.

Reservas não pagas em 10 minutos (configurável) expiram sozinhas: um Cron Job da
Vercel chama `/api/cron/expire-reservations` a cada minuto, que devolve o estoque
automaticamente.

## O que é manual hoje e pode virar automático depois

- **Confirmação de pagamento**: hoje o admin confirma manualmente no painel.
  A tabela `payments` já está pronta para um gateway Pix (Mercado Pago, EFI etc.)
  escrever nela via webhook — nesse dia, troca-se só a função `confirm_order_payment`
  pra ser chamada pelo webhook em vez de pelo botão do admin.
- **Fotos dos produtos**: suba manualmente no Storage do Supabase e cole a URL
  no cadastro do produto.

## Estrutura de pastas

```
app/              páginas (catálogo, carrinho, checkout, admin) e API routes
components/       componentes React reutilizáveis
lib/              clientes Supabase, tipos, carrinho (zustand), formatação
db/               schema.sql, functions.sql (reserva atômica), seed.sql
```

## Uma observação importante

Este código foi escrito e revisado com cuidado, mas **não foi executado/testado**
num ambiente real (o ambiente onde foi gerado não tem acesso à internet para rodar
`npm install`). Antes de divulgar pro público, faça um teste ponta a ponta você
mesma: adicionar produto ao carrinho, reservar, ver a tela de Pix, confirmar
pagamento no painel e conferir se o estoque bate.
