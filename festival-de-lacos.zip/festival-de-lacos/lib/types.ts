export type Product = {
  id: string;
  code: string;
  name: string;
  description: string | null;
  category: string | null;
  color: string;
  size: string | null;
  price: number;
  photo_url: string | null;
  stock_total: number;
  stock_reserved: number;
  stock_sold: number;
  stock_available: number;
  availability_label: "disponivel" | "ultimo_par" | "esgotado";
  is_active: boolean;
};

export type CartItem = {
  productId: string;
  code: string;
  name: string;
  color: string;
  price: number;
  photoUrl: string | null;
  quantity: number;
  maxAvailable: number;
};

export type DeliveryMethod = "retirar" | "receber";

export type OrderStatus =
  | "reservado"
  | "aguardando_pagamento"
  | "pagamento_informado"
  | "pago"
  | "separando"
  | "pronto_para_retirada"
  | "em_entrega"
  | "entregue"
  | "cancelado"
  | "expirado";

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  reservado: "Reservado",
  aguardando_pagamento: "Aguardando pagamento",
  pagamento_informado: "Pagamento informado",
  pago: "Pago",
  separando: "Separando",
  pronto_para_retirada: "Pronto para retirada",
  em_entrega: "Em entrega",
  entregue: "Entregue",
  cancelado: "Cancelado",
  expirado: "Expirado",
};
