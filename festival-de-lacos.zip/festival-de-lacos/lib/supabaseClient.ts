// Cliente para uso no BROWSER (client components).
// Usa a anon key — que, graças ao RLS do schema.sql, só consegue LER
// produtos ativos e a view public_settings. Não escreve em nada.
import { createBrowserClient } from "@supabase/ssr";

export function supabaseBrowser() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
