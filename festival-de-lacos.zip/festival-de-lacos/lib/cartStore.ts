"use client";
// Carrinho fica no localStorage do navegador — nada de estoque é
// descontado aqui. É só uma "lista de intenção" até o cliente
// clicar em "Continuar" e o backend tentar reservar de verdade.
import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { CartItem } from "./types";

type CartState = {
  items: CartItem[];
  add: (item: CartItem) => void;
  remove: (productId: string) => void;
  setQuantity: (productId: string, quantity: number) => void;
  clear: () => void;
  total: () => number;
};

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      add: (item) => {
        const existing = get().items.find((i) => i.productId === item.productId);
        if (existing) {
          const qty = Math.min(existing.quantity + item.quantity, item.maxAvailable);
          set({
            items: get().items.map((i) =>
              i.productId === item.productId ? { ...i, quantity: qty } : i
            ),
          });
        } else {
          set({ items: [...get().items, item] });
        }
      },
      remove: (productId) =>
        set({ items: get().items.filter((i) => i.productId !== productId) }),
      setQuantity: (productId, quantity) =>
        set({
          items: get().items.map((i) =>
            i.productId === productId
              ? { ...i, quantity: Math.max(1, Math.min(quantity, i.maxAvailable)) }
              : i
          ),
        }),
      clear: () => set({ items: [] }),
      total: () => get().items.reduce((s, i) => s + i.price * i.quantity, 0),
    }),
    { name: "festival-de-lacos-cart" }
  )
);
