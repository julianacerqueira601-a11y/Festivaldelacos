// Cliente para uso SÓ NO SERVIDOR (API routes / server components).
// Usa a service_role key, que ignora RLS — por isso este arquivo
// NUNCA pode ser importado em um "use client".
import { createClient } from "@supabase/supabase-js";

export function supabaseAdmin() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}
