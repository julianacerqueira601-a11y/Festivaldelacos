export function formatMoney(v: number) {
  return v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export function pad4(n: number) {
  return String(n).padStart(4, "0");
}
