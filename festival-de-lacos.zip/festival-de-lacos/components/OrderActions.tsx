"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

const NEXT_STEPS: Record<string, { status: string; label: string }[]> = {
  reservado: [],
  aguardando_pagamento: [],
  pagamento_informado: [{ status: "__confirm__", label: "Confirmar pagamento" }],
  pago: [{ status: "separando", label: "Marcar como separando" }],
  separando: [{ status: "pronto_para_retirada", label: "Pronto para retirada" }, { status: "em_entrega", label: "Em entrega" }],
  pronto_para_retirada: [{ status: "entregue", label: "Entregue" }],
  em_entrega: [{ status: "entregue", label: "Entregue" }],
};

export default function OrderActions({ orderId, status }: { orderId: string; status: string }) {
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const steps = NEXT_STEPS[status] ?? [];
  const canCancel = !["entregue", "cancelado", "expirado"].includes(status);

  async function runAction(target: string) {
    setLoading(true);
    const url =
      target === "__confirm__"
        ? `/api/admin/orders/${orderId}/confirm-payment`
        : `/api/admin/orders/${orderId}/status`;
    await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: target === "__confirm__" ? undefined : JSON.stringify({ status: target }),
    });
    setLoading(false);
    router.refresh();
  }

  if (steps.length === 0 && !canCancel) return null;

  return (
    <div className="flex flex-wrap gap-2 mt-3">
      {steps.map((s) => (
        <button
          key={s.status}
          disabled={loading}
          onClick={() => runAction(s.status)}
          className="btn-primary !py-1.5 !px-3 !text-[11px]"
        >
          {s.label}
        </button>
      ))}
      {canCancel && (
        <button
          disabled={loading}
          onClick={() => runAction("cancelado")}
          className="btn-outline !py-1.5 !px-3 !text-[11px]"
        >
          Cancelar pedido
        </button>
      )}
    </div>
  );
}
