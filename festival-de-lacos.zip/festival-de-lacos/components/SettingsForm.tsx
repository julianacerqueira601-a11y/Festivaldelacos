"use client";
import { useState } from "react";

export default function SettingsForm({ initial }: { initial: any }) {
  const [form, setForm] = useState({
    festival_name: initial?.festival_name ?? "",
    festival_description: initial?.festival_description ?? "",
    pix_key: initial?.pix_key ?? "",
    pix_receiver_name: initial?.pix_receiver_name ?? "",
    pix_qr_code_url: initial?.pix_qr_code_url ?? "",
    reservation_minutes: initial?.reservation_minutes ?? 10,
    whatsapp_number: initial?.whatsapp_number ?? "",
    confirmation_message: initial?.confirmation_message ?? "",
    allow_pickup: initial?.allow_pickup ?? true,
    allow_delivery: initial?.allow_delivery ?? true,
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  async function handleSave() {
    setSaving(true);
    setSaved(false);
    const res = await fetch("/api/admin/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setSaving(false);
    if (res.ok) setSaved(true);
  }

  const F = (key: keyof typeof form, label: string, type = "text") => (
    <label className="flex flex-col gap-1 text-xs font-semibold text-ink2">
      {label}
      <input
        type={type}
        value={form[key] as any}
        onChange={(e) => setForm({ ...form, [key]: type === "number" ? Number(e.target.value) : e.target.value })}
        className="input"
      />
    </label>
  );

  return (
    <div className="card p-4 flex flex-col gap-3">
      {F("festival_name", "Nome do festival")}
      {F("festival_description", "Descrição")}
      {F("pix_key", "Chave Pix")}
      {F("pix_receiver_name", "Nome do recebedor")}
      {F("pix_qr_code_url", "URL da imagem do QR Code Pix")}
      {F("reservation_minutes", "Tempo de reserva (minutos)", "number")}
      {F("whatsapp_number", "WhatsApp (só números, com DDI)")}
      <label className="flex flex-col gap-1 text-xs font-semibold text-ink2">
        Mensagem de confirmação
        <textarea
          value={form.confirmation_message}
          onChange={(e) => setForm({ ...form, confirmation_message: e.target.value })}
          className="input"
          rows={2}
        />
      </label>

      <div className="flex gap-4 mt-1">
        <label className="flex items-center gap-2 text-xs font-semibold">
          <input type="checkbox" checked={form.allow_pickup} onChange={(e) => setForm({ ...form, allow_pickup: e.target.checked })} />
          Permitir retirada
        </label>
        <label className="flex items-center gap-2 text-xs font-semibold">
          <input type="checkbox" checked={form.allow_delivery} onChange={(e) => setForm({ ...form, allow_delivery: e.target.checked })} />
          Permitir entrega
        </label>
      </div>

      <button onClick={handleSave} disabled={saving} className="btn-primary mt-2">
        {saving ? "Salvando..." : "Salvar configurações"}
      </button>
      {saved && <p className="text-green-700 text-xs">Salvo com sucesso.</p>}

      <style jsx global>{`
        .input { width:100%; border:1px solid rgba(0,0,0,0.1); border-radius:10px; padding:10px 12px; font-size:13.5px; background:white; }
      `}</style>
    </div>
  );
}
