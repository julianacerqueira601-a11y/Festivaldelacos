"use client";
import Image from "next/image";
import type { Product } from "@/lib/types";
import { formatMoney } from "@/lib/format";
import { useCart } from "@/lib/cartStore";
import Link from "next/link";

export default function ProductCard({ product }: { product: Product }) {
  const add = useCart((s) => s.add);
  const esgotado = product.availability_label === "esgotado";
  const ultimoPar = product.availability_label === "ultimo_par";

  return (
    <div className="card overflow-hidden flex flex-col">
      <Link href={`/produto/${product.id}`} className="block relative aspect-square bg-bgalt">
        {product.photo_url ? (
          <Image src={product.photo_url} alt={product.name} fill className="object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-ink2 text-xs text-center p-4">
            [FOTO DO PRODUTO]
          </div>
        )}
        {esgotado && (
          <span className="absolute top-2 left-2 bg-ink text-bg text-[10px] font-bold px-2 py-1 rounded-full">
            🔴 ESGOTADO
          </span>
        )}
        {ultimoPar && !esgotado && (
          <span className="absolute top-2 left-2 bg-amarelo text-ink text-[10px] font-bold px-2 py-1 rounded-full">
            🟠 ÚLTIMO PAR
          </span>
        )}
      </Link>
      <div className="p-3 flex flex-col gap-1 flex-1">
        <span className="text-[10px] tracking-wider text-ink2 font-semibold uppercase">
          {product.code}
        </span>
        <h3 className="font-display text-[15px] leading-tight">{product.name}</h3>
        <p className="text-xs text-ink2">{product.color}</p>
        <div className="flex items-center justify-between mt-1">
          <span className="font-bold text-sm">{formatMoney(product.price)}</span>
        </div>
        {!esgotado && !ultimoPar && (
          <span className="text-[11px] text-green-700">
            🟢 {product.stock_available} par{product.stock_available > 1 ? "es" : ""} disponíve
            {product.stock_available > 1 ? "is" : "l"}
          </span>
        )}
        <button
          disabled={esgotado}
          onClick={() =>
            add({
              productId: product.id,
              code: product.code,
              name: product.name,
              color: product.color,
              price: product.price,
              photoUrl: product.photo_url,
              quantity: 1,
              maxAvailable: product.stock_available,
            })
          }
          className="mt-2 btn-primary w-full !py-2 !text-xs disabled:opacity-40 disabled:cursor-not-allowed"
        >
          {esgotado ? "Esgotado" : "Adicionar"}
        </button>
      </div>
    </div>
  );
}
