"use client";
import { useCart } from "@/lib/cartStore";
import { useRouter } from "next/navigation";
import type { Product } from "@/lib/types";

export default function AddToCartButton({ product }: { product: Product }) {
  const add = useCart((s) => s.add);
  const router = useRouter();
  const esgotado = product.availability_label === "esgotado";

  return (
    <button
      disabled={esgotado}
      onClick={() => {
        add({
          productId: product.id,
          code: product.code,
          name: product.name,
          color: product.color,
          price: product.price,
          photoUrl: product.photo_url,
          quantity: 1,
          maxAvailable: product.stock_available,
        });
        router.push("/carrinho");
      }}
      className="btn-primary w-full mt-6 disabled:opacity-40"
    >
      {esgotado ? "Esgotado" : "Adicionar ao carrinho"}
    </button>
  );
}
