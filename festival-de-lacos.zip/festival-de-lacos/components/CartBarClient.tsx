"use client";
import { useCart } from "@/lib/cartStore";
import { formatMoney } from "@/lib/format";
import Link from "next/link";

export default function CartBarClient() {
  const items = useCart((s) => s.items);
  const total = useCart((s) => s.total());
  const count = items.reduce((s, i) => s + i.quantity, 0);

  if (count === 0) return null;

  return (
    <Link
      href="/carrinho"
      className="mx-4 mb-4 flex items-center justify-between bg-ink text-bg rounded-full px-5 py-4 shadow-lg"
    >
      <span className="text-sm font-semibold">
        🛍️ {count} item{count > 1 ? "s" : ""}
      </span>
      <span className="text-sm font-bold">{formatMoney(total)} · Ver carrinho</span>
    </Link>
  );
}
