"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewProductForm() {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ code: "", name: "", color: "", category: "Laços", price: "", stock: "" });
  const router = useRouter();

  async function handleSave() {
    setLoading(true);
    const res = await fetch("/api/admin/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code: form.code,
        name: form.name,
        color: form.color,
        category: form.category,
        price: parseFloat(form.price),
        stock: parseInt(form.stock, 10),
      }),
    });
    setLoading(false);
    if (res.ok) {
      setForm({ code: "", name: "", color: "", category: "Laços", price: "", stock: "" });
      setOpen(false);
      router.refresh();
    }
  }

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="btn-primary mb-4">
        + Novo produto
      </button>
    );
  }

  return (
    <div className="card p-4 mb-4">
      <div className="grid grid-cols-2 gap-2">
        <input placeholder="Código (ex: L006)" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} className="input" />
        <input placeholder="Nome" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input" />
        <input placeholder="Cor" value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} className="input" />
        <input placeholder="Categoria" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="input" />
        <input placeholder="Preço" type="number" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} className="input" />
        <input placeholder="Estoque" type="number" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} className="input" />
      </div>
      <div className="flex gap-2 mt-3">
        <button onClick={handleSave} disabled={loading} className="btn-primary !py-2 !text-xs">
          {loading ? "Salvando..." : "Salvar"}
        </button>
        <button onClick={() => setOpen(false)} className="btn-outline !py-2 !text-xs">
          Cancelar
        </button>
      </div>
      <style jsx global>{`
        .input { width:100%; border:1px solid rgba(0,0,0,0.1); border-radius:10px; padding:9px 11px; font-size:13px; background:white; }
      `}</style>
    </div>
  );
}
