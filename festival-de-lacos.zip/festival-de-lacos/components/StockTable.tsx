"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { formatMoney } from "@/lib/format";
import type { Product } from "@/lib/types";

export default function StockTable({ products }: { products: Product[] }) {
  return (
    <div className="flex flex-col gap-2">
      {products.map((p) => (
        <Row key={p.id} product={p} />
      ))}
    </div>
  );
}

function Row({ product }: { product: Product }) {
  const [editing, setEditing] = useState(false);
  const [price, setPrice] = useState(String(product.price));
  const [stock, setStock] = useState(String(product.stock_total));
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function save() {
    setLoading(true);
    await fetch(`/api/admin/products/${product.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ price: parseFloat(price), stock_total: parseInt(stock, 10) }),
    });
    setLoading(false);
    setEditing(false);
    router.refresh();
  }

  async function toggleActive() {
    await fetch(`/api/admin/products/${product.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ is_active: !product.is_active }),
    });
    router.refresh();
  }

  return (
    <div className="card p-3 flex items-center gap-3">
      <div className="flex-1">
        <p className="font-display text-sm">
          {product.code} — {product.name} <span className="text-ink2 text-xs">({product.color})</span>
        </p>
        {!editing ? (
          <p className="text-xs text-ink2 mt-0.5">
            {formatMoney(product.price)} · estoque {product.stock_total} · reservado{" "}
            {product.stock_reserved} · vendido {product.stock_sold} · disponível{" "}
            <strong>{product.stock_available}</strong>
          </p>
        ) : (
          <div className="flex gap-2 mt-1">
            <input value={price} onChange={(e) => setPrice(e.target.value)} className="w-20 text-xs border rounded px-2 py-1" />
            <input value={stock} onChange={(e) => setStock(e.target.value)} className="w-16 text-xs border rounded px-2 py-1" />
          </div>
        )}
      </div>
      <div className="flex flex-col gap-1 items-end">
        <button
          onClick={toggleActive}
          className={`text-[10px] font-bold px-2 py-1 rounded-full ${product.is_active ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}
        >
          {product.is_active ? "Ativo" : "Inativo"}
        </button>
        {editing ? (
          <button onClick={save} disabled={loading} className="text-[11px] underline">
            Salvar
          </button>
        ) : (
          <button onClick={() => setEditing(true)} className="text-[11px] underline">
            Editar
          </button>
        )}
      </div>
    </div>
  );
}
