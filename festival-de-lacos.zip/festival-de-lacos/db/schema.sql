-- ============================================================
-- FESTIVAL DE LAÇOS — schema do banco (Postgres / Supabase)
-- ============================================================

create extension if not exists "uuid-ossp";

-- ---------- PRODUTOS ----------
create table products (
  id uuid primary key default uuid_generate_v4(),
  code text unique not null,              -- ex: L001
  name text not null,                     -- ex: Boutique
  description text,
  category text,                          -- ex: Laços, Kits
  color text not null,
  size text,
  price numeric(10,2) not null check (price >= 0),
  photo_url text,
  stock_total int not null default 0 check (stock_total >= 0),
  stock_reserved int not null default 0 check (stock_reserved >= 0),
  stock_sold int not null default 0 check (stock_sold >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint stock_consistent check (stock_reserved + stock_sold <= stock_total)
);

create or replace view products_with_availability as
  select *,
         (stock_total - stock_reserved - stock_sold) as stock_available,
         case
           when (stock_total - stock_reserved - stock_sold) <= 0 then 'esgotado'
           when (stock_total - stock_reserved - stock_sold) = 1 then 'ultimo_par'
           else 'disponivel'
         end as availability_label
  from products;

-- ---------- CLIENTES ----------
create table customers (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  whatsapp text not null,
  neighborhood text,
  created_at timestamptz not null default now(),
  unique (whatsapp)
);

-- ---------- PEDIDOS ----------
create type order_status as enum (
  'reservado','aguardando_pagamento','pagamento_informado','pago',
  'separando','pronto_para_retirada','em_entrega','entregue',
  'cancelado','expirado'
);

create type delivery_method as enum ('retirar', 'receber');

create table orders (
  id uuid primary key default uuid_generate_v4(),
  order_number serial unique,
  customer_id uuid not null references customers(id),
  status order_status not null default 'reservado',
  delivery_method delivery_method not null,
  address_street text,
  address_number text,
  address_complement text,
  address_neighborhood text,
  address_reference text,
  notes text,
  total numeric(10,2) not null default 0,
  reserved_until timestamptz not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------- ITENS DO PEDIDO ----------
create table order_items (
  id uuid primary key default uuid_generate_v4(),
  order_id uuid not null references orders(id) on delete cascade,
  product_id uuid not null references products(id),
  quantity int not null check (quantity > 0),
  unit_price numeric(10,2) not null,
  subtotal numeric(10,2) not null
);

-- ---------- PAGAMENTOS ----------
create table payments (
  id uuid primary key default uuid_generate_v4(),
  order_id uuid not null references orders(id) on delete cascade,
  method text not null default 'pix',
  amount numeric(10,2) not null,
  status text not null default 'aguardando' check (status in ('aguardando','informado','confirmado','recusado')),
  informed_at timestamptz,
  confirmed_at timestamptz,
  confirmed_by text,
  gateway_reference text,
  created_at timestamptz not null default now()
);

-- ---------- ADMIN ----------
create table admin_users (
  id uuid primary key references auth.users(id) on delete cascade,
  name text,
  created_at timestamptz not null default now()
);

-- ---------- CONFIGURAÇÕES ----------
create table settings (
  id int primary key default 1,
  festival_name text not null default 'Festival de Laços',
  festival_description text default 'Modelos exclusivos • Quantidades limitadas',
  pix_key text,
  pix_receiver_name text,
  pix_qr_code_url text,
  reservation_minutes int not null default 10,
  whatsapp_number text,
  confirmation_message text,
  allow_pickup boolean not null default true,
  allow_delivery boolean not null default true,
  constraint singleton check (id = 1)
);
insert into settings (id) values (1);

-- ---------- HISTÓRICO ----------
create table inventory_movements (
  id uuid primary key default uuid_generate_v4(),
  product_id uuid references products(id),
  order_id uuid references orders(id),
  event text not null,
  detail jsonb,
  created_at timestamptz not null default now()
);

-- ---------- ÍNDICES ----------
create index idx_orders_status on orders(status);
create index idx_orders_reserved_until on orders(reserved_until);
create index idx_order_items_order on order_items(order_id);
create index idx_products_active on products(is_active);

-- ---------- RLS ----------
alter table products enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;
alter table customers enable row level security;
alter table payments enable row level security;
alter table settings enable row level security;

create policy "produtos ativos sao publicos para leitura"
  on products for select using (is_active = true);

create policy "settings leitura bruta bloqueada para anon"
  on settings for select using (false);

create view public_settings as
  select festival_name, festival_description, pix_qr_code_url,
         reservation_minutes, whatsapp_number, allow_pickup, allow_delivery
  from settings where id = 1;

-- Nenhuma policy de INSERT/UPDATE/DELETE existe para o papel "anon":
-- o navegador do cliente (anon key) não consegue escrever em NADA.
-- Toda escrita (reservar, confirmar pagamento, mexer em estoque) passa
-- pelas API routes do Next.js, que usam a service_role key no servidor.
