-- Dados de teste — 5 produtos fictícios do briefing
insert into products (code, name, color, category, price, stock_total, description)
values
  ('L001', 'Boutique', 'Rosa',    'Laços', 15.00, 3, 'Laço boutique artesanal, acabamento delicado.'),
  ('L002', 'Boutique', 'Azul',    'Laços', 15.00, 2, 'Laço boutique artesanal, acabamento delicado.'),
  ('L003', 'Flor',     'Lilás',   'Laços', 18.00, 1, 'Laço modelo flor, peça única.'),
  ('L004', 'Borboleta','Rosa',    'Laços', 20.00, 4, 'Laço modelo borboleta.'),
  ('L005', 'Princess', 'Azul',    'Laços', 22.00, 2, 'Laço modelo princess, edição do festival.');

update settings set
  festival_name = 'Festival de Laços',
  festival_description = 'Modelos exclusivos • Quantidades limitadas',
  reservation_minutes = 10,
  pix_receiver_name = '[NOME A DEFINIR]',
  pix_key = '[CHAVE PIX A DEFINIR]',
  whatsapp_number = '[WHATSAPP A DEFINIR]',
  confirmation_message = 'Pedido recebido! Seu pagamento será conferido. Assim que for confirmado, seu pedido será separado.'
where id = 1;
