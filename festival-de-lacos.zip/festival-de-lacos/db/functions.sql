-- ============================================================
-- FUNÇÕES — reserva atômica de estoque, expiração, confirmação
-- ============================================================

-- ------------------------------------------------------------
-- reserve_products: tenta reservar uma lista de itens de uma vez.
-- Se QUALQUER item não tiver estoque suficiente, a função inteira
-- falha e NADA é reservado (tudo ou nada).
--
-- items: jsonb no formato [{"product_id": "...", "quantity": 2}, ...]
--
-- O "FOR UPDATE" implícito no UPDATE trava a linha do produto
-- durante a transação: se Maria e Joana clicarem no mesmo
-- instante, o Postgres processa uma de cada vez, nunca em paralelo
-- sobre a mesma linha — é isso que impede vender o último par duas vezes.
-- ------------------------------------------------------------
create or replace function reserve_products(items jsonb, p_minutes int)
returns table(product_id uuid, ok boolean, available int) as $$
declare
  item jsonb;
  v_product_id uuid;
  v_qty int;
  v_updated int;
begin
  -- primeiro passa por todos os itens tentando decrementar;
  -- se algum falhar, a exceção reverte a transação inteira
  for item in select * from jsonb_array_elements(items)
  loop
    v_product_id := (item->>'product_id')::uuid;
    v_qty := (item->>'quantity')::int;

    update products
      set stock_reserved = stock_reserved + v_qty,
          updated_at = now()
      where id = v_product_id
        and is_active = true
        and (stock_total - stock_reserved - stock_sold) >= v_qty;

    get diagnostics v_updated = row_count;

    if v_updated = 0 then
      raise exception 'estoque insuficiente para o produto %', v_product_id
        using errcode = 'P0001';
    end if;
  end loop;

  return query
    select p.id, true, (p.stock_total - p.stock_reserved - p.stock_sold)
    from products p
    where p.id in (select (i->>'product_id')::uuid from jsonb_array_elements(items) i);
end;
$$ language plpgsql;

-- ------------------------------------------------------------
-- release_reservation: devolve o estoque reservado de um pedido
-- (usado quando a reserva expira ou o pedido é cancelado)
-- ------------------------------------------------------------
create or replace function release_reservation(p_order_id uuid)
returns void as $$
begin
  update products p
    set stock_reserved = stock_reserved - oi.quantity,
        updated_at = now()
    from order_items oi
    where oi.order_id = p_order_id
      and oi.product_id = p.id;
end;
$$ language plpgsql;

-- ------------------------------------------------------------
-- confirm_payment: move reservado -> vendido definitivamente
-- ------------------------------------------------------------
create or replace function confirm_order_payment(p_order_id uuid, p_confirmed_by text)
returns void as $$
begin
  update products p
    set stock_reserved = stock_reserved - oi.quantity,
        stock_sold = stock_sold + oi.quantity,
        updated_at = now()
    from order_items oi
    where oi.order_id = p_order_id
      and oi.product_id = p.id;

  update orders set status = 'pago', updated_at = now() where id = p_order_id;

  update payments
    set status = 'confirmado', confirmed_at = now(), confirmed_by = p_confirmed_by
    where order_id = p_order_id;

  insert into inventory_movements (order_id, event, detail)
  values (p_order_id, 'pagamento_confirmado', jsonb_build_object('confirmed_by', p_confirmed_by));
end;
$$ language plpgsql;

-- ------------------------------------------------------------
-- expire_stale_reservations: roda a cada minuto (via cron).
-- Devolve estoque de todo pedido cuja reserva venceu e que
-- ainda não teve pagamento informado nem confirmado.
-- ------------------------------------------------------------
create or replace function expire_stale_reservations()
returns int as $$
declare
  v_order record;
  v_count int := 0;
begin
  for v_order in
    select id from orders
    where reserved_until < now()
      and status in ('reservado', 'aguardando_pagamento')
  loop
    perform release_reservation(v_order.id);

    update orders set status = 'expirado', updated_at = now() where id = v_order.id;

    insert into inventory_movements (order_id, event)
    values (v_order.id, 'reserva_expirada');

    v_count := v_count + 1;
  end loop;

  return v_count;
end;
$$ language plpgsql;
