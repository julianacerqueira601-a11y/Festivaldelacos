import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        rosa: "#F3B6C8",
        lilas: "#C8B6E6",
        azul: "#A9D8F2",
        amarelo: "#F6D66A",
        bg: "#FFFDF9",
        bgalt: "#FBF5EF",
        ink: "#403B46",
        ink2: "#756D78",
      },
      fontFamily: {
        display: ["Fraunces", "serif"],
        sans: ["Inter", "sans-serif"],
      },
      borderRadius: {
        xl2: "18px",
      },
    },
  },
  plugins: [],
};
export default config;
